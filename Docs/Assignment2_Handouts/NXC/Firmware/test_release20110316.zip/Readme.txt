1. Extract the zip contents over your existing BricxCC installation directory with 
the directory structure maintained.
2. Reset Preferences to their default values in order to see all the new Command 
(API functions) and constants in NXC syntax highlighting.
